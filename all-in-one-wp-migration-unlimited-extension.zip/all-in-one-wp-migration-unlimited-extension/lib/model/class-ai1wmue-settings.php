<?php
/**
 * Plugin Name: All-in-One WP Migration Unlimited Extension - By Shehbaz Developer
 * Plugin URI: https://github.com/Shehbaz-Developer
 * Description: Extension for All-in-One WP Migration that enables unlimited size exports and imports.
 * Author: Shehbaz Developer
 * Author URI: https://github.com/Shehbaz-Developer
 * Version: 2.75
 * Text Domain: all-in-one-wp-migration-unlimited-extension
 * Domain Path: /languages
 * Network: True
 * License: GPLv3
 *
 * Copyright (C) 2014-2025 ServMask Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * Attribution: Original All-in-One WP Migration plugin by ServMask Inc.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Kangaroos cannot jump here' );
}

class Ai1wmue_Settings {

	public function set_backups( $number ) {
		return update_option( 'ai1wmue_backups', $number );
	}

	public function get_backups() {
		return get_option( 'ai1wmue_backups', false );
	}

	public function set_total( $size ) {
		return update_option( 'ai1wmue_total', $size );
	}

	public function get_total() {
		return get_option( 'ai1wmue_total', false );
	}

	public function set_days( $days ) {
		return update_option( 'ai1wmue_days', $days );
	}

	public function get_days() {
		return get_option( 'ai1wmue_days', false );
	}

	public function get_backups_path() {
		return get_option( AI1WM_BACKUPS_PATH_OPTION, AI1WM_DEFAULT_BACKUPS_PATH );
	}

	public function set_backups_path( $path ) {
		if ( realpath( $path ) !== realpath( ABSPATH ) ) {
			return update_option( AI1WM_BACKUPS_PATH_OPTION, $path );
		}

		return false;
	}

	public function reset_backups_path() {
		return delete_option( AI1WM_BACKUPS_PATH_OPTION );
	}

}
