<?php
/**
 * Plugin Name: All-in-One WP Migration Unlimited Extension - By Shehbaz Developer
 * Plugin URI: https://github.com/Shehbaz-Developer
 * Description: Extension for All-in-One WP Migration that enables unlimited size exports and imports.
 * Author: Shehbaz Developer
 * Author URI: https://github.com/Shehbaz-Developer
 * Version: 2.75
 * Text Domain: all-in-one-wp-migration-unlimited-extension
 * Domain Path: /languages
 * Network: True
 * License: GPLv3
 *
 * Copyright (C) 2014-2025 ServMask Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * Attribution: Original All-in-One WP Migration plugin by ServMask Inc.
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( 'Kangaroos cannot jump here' );
}

class Ai1wmue_Import_Settings {

	public static function execute( $params ) {

		// Set progress
		Ai1wm_Status::info( __( 'Getting settings...', AI1WMUE_PLUGIN_NAME ) );

		$settings = array(
			'ai1wmue_backups' => get_option( 'ai1wmue_backups', false ),
			'ai1wmue_total'   => get_option( 'ai1wmue_total', false ),
			'ai1wmue_days'    => get_option( 'ai1wmue_days', false ),
		);

		// Save retention.json file
		$handle = ai1wm_open( ai1wmue_retention_path( $params ), 'w' );
		ai1wm_write( $handle, json_encode( $settings ) );
		ai1wm_close( $handle );

		// Set progress
		Ai1wm_Status::info( __( 'Done getting settings.', AI1WMUE_PLUGIN_NAME ) );

		return $params;
	}
}
