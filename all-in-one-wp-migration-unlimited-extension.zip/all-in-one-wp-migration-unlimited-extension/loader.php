<?php
/**
 * Plugin Name: All-in-One WP Migration Unlimited Extension - By Shehbaz Developer
 * Plugin URI: https://github.com/Shehbaz-Developer
 * Description: Extension for All-in-One WP Migration that enables unlimited size exports and imports.
 * Author: Shehbaz Developer
 * Author URI: https://github.com/Shehbaz-Developer
 * Version: 2.75
 * Text Domain: all-in-one-wp-migration-unlimited-extension
 * Domain Path: /languages
 * Network: True
 * License: GPLv3
 *
 * Copyright (C) 2014-2025 ServMask Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * Attribution: Original All-in-One WP Migration plugin by ServMask Inc.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Kangaroos cannot jump here' );
}

// Include all the files that you want to load in here
if ( defined( 'WP_CLI' ) ) {
	require_once AI1WMUE_VENDOR_PATH . '/servmask/command/ai1wm-wp-cli.php';
}

require_once AI1WMUE_VENDOR_PATH . '/servmask/pro/ai1wmve.php';

require_once AI1WMUE_CONTROLLER_PATH . '/class-ai1wmue-main-controller.php';
require_once AI1WMUE_CONTROLLER_PATH . '/class-ai1wmue-settings-controller.php';

require_once AI1WMUE_MODEL_PATH . '/export/class-ai1wmue-export-retention.php';
require_once AI1WMUE_MODEL_PATH . '/import/class-ai1wmue-import-database.php';
require_once AI1WMUE_MODEL_PATH . '/import/class-ai1wmue-import-settings.php';
require_once AI1WMUE_MODEL_PATH . '/import/class-ai1wmue-import-upload.php';

require_once AI1WMUE_MODEL_PATH . '/class-ai1wmue-settings.php';
